import shutil
shutil.make_archive("../ingest_weather_data", 'zip', ".")
